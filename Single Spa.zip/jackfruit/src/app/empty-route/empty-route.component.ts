import { Component } from '@angular/core';

@Component({
  selector: 'jackfruit-empty-route',
  template: '',
})
export class EmptyRouteComponent {
}
