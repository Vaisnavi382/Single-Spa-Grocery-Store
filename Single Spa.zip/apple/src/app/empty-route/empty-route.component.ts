import { Component } from '@angular/core';

@Component({
  selector: 'apple-empty-route',
  template: '',
})
export class EmptyRouteComponent {
}
