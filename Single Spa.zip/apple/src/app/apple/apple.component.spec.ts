import { ComponentFixture, TestBed } from '@angular/core/testing';

import { appleComponent } from './apple.component';

describe('appleComponent', () => {
  let component: appleComponent;
  let fixture: ComponentFixture<appleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ appleComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(appleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
