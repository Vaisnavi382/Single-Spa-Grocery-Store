import { Component } from '@angular/core';

@Component({
  selector: 'blackberry-empty-route',
  template: '',
})
export class EmptyRouteComponent {
}
