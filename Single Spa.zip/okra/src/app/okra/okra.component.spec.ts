import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OkraComponent } from './okra.component';

describe('OkraComponent', () => {
  let component: OkraComponent;
  let fixture: ComponentFixture<OkraComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OkraComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OkraComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
