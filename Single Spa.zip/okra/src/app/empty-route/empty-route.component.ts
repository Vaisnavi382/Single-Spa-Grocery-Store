import { Component } from '@angular/core';

@Component({
  selector: 'okra-empty-route',
  template: '',
})
export class EmptyRouteComponent {
}
