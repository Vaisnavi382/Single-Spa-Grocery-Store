Steps to run :

1. npm i
2. ng serve
