import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';


@Component({
    selector : 'strawberry',
    templateUrl: 'strawberry.component.html',
    styleUrls: ['strawberry.component.css']
})
export class StrawberryComponent {
    pageTitle = 'strawberry';
    id = 0;

    constructor(private route: ActivatedRoute,
        private router: Router) {
        this.id = +this.route.snapshot.paramMap.get('id')!;
        }

    onBack(): void {
        this.router.navigate(['/products']);
    }
}
