import { Component } from '@angular/core';

@Component({
  selector: 'strawberry-empty-route',
  template: '',
})
export class EmptyRouteComponent {
}
