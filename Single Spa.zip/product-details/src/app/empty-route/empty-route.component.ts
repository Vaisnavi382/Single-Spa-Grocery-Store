import { Component } from '@angular/core';

@Component({
  selector: 'product-detail-empty-route',
  template: '',
})
export class EmptyRouteComponent {
}
