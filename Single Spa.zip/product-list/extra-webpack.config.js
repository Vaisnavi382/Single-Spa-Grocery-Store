// import 'bootstrap/dist/css/bootstrap.min.css';

const singleSpaAngularWebpack = require('single-spa-angular/lib/webpack').default;


module.exports = (angularWebpackConfig, options) => {
  const singleSpaWebpackConfig = singleSpaAngularWebpack(angularWebpackConfig, options);

  // Modify the output.publicPath option
  singleSpaWebpackConfig.output.publicPath = 'http://localhost:4203/';
  
  externals: {
   bootstrap : '@ng-bootstrap/ng-bootstrap'
  };
  {  compilerOptions: {  resolveJsonModule: true;
    esModuleInterop : true };
  };
  // Return the modified webpack configuration
  return singleSpaWebpackConfig;
};
