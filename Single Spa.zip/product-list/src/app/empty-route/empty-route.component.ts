import { Component } from '@angular/core';

@Component({
  selector: 'app3-empty-route',
  template: '',
})
export class EmptyRouteComponent {
}
