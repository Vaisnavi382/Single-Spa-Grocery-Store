import { Component } from '@angular/core';
import { OrderByPipe } from './product-list/orderby.pipe';

@Component({
  selector: 'app3-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  
})
export class AppComponent {
  title = 'app1';
}
