import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmptyRouteComponent } from './empty-route/empty-route.component';
import { APP_BASE_HREF } from '@angular/common';
import { LoginComponent } from '../../../app2/src/app/login/login.component';
import { WelcomeComponent } from '../../../app1/src/app/welcome/welcome.component'
import { ProductListComponent} from './product-list/product-list.component';

const routes: Routes = [
  { path: '**', component: EmptyRouteComponent },
  { path: 'app2', component: LoginComponent },
  { path: 'app1', component: WelcomeComponent }, 
  { path : 'product-list', component : ProductListComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: [
    { provide: APP_BASE_HREF, useValue: '/' },
  ],
})
export class AppRoutingModule { }

