import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ProductListComponent } from './product-list.component';
// import { ProductDetailComponent } from '../../../product-detail/src/app/product-detail/product-detail.component';
// import { CartComponent } from './cart/cart.component';


const routes: Routes = [
  {
    path: '',
    children: [
      { path: '', component: ProductListComponent },
      // { path: 'cart', component: CartComponent },
      //  { path: ':brinjal', component: ProductDetailComponent }
    ],
  }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProductsRoutingModule { }
