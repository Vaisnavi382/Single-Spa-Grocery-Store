import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { ProductsRoutingModule } from './products-routing.module';
import { ProductListComponent } from './/product-list.component';
import { Route, Router } from '@angular/router';
import { RouterModule } from '@angular/router';
// import { ProductDetailComponent } from './product-detail/product-detail.component';
// import { CartComponent } from './cart/cart.component';
import { OrderByPipe } from './orderby.pipe';
import { ProductService } from './product.service';
// import { AuthGuardService } from './auth-guard.service';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    ProductsRoutingModule, RouterModule, HttpClientModule
  ],
  declarations: [],
  providers: [ProductService]
})
export class ProductsModule { }
