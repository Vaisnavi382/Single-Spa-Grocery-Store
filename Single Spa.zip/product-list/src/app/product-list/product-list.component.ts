import { AfterViewInit, Component, ElementRef, OnInit, Renderer2, ViewChild } from '@angular/core';
import { assetUrl } from 'src/single-spa/asset-url';
import { ProductService } from './product.service';
import { CartComponent } from '../../../cart/src/app/cart/cart.component';
import { Product } from './product';
import { CartService } from '../../../../cart/src/app/cart/cart.service';
import { Pipe, PipeTransform } from '@angular/core';
import { JackfruitComponent } from '../../../../jackfruit/src/app/jackfruit/jackfruit.component';
import { ProductDetailComponent} from '../../../product-details/src/app/product-detail/product-detail.component';
@Component({
    selector : 'product-list',
    templateUrl: 'product-list.component.html',
    styleUrls: ['product-list.component.css']
})
export class ProductListComponent{
    
    v1 : boolean = true;
    
    v(){
        this.v1=true;
    }
    f(){
        this.v1=false;
    }
    
    
}


