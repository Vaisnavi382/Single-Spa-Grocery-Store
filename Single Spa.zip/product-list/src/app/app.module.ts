import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Pipe } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmptyRouteComponent } from './empty-route/empty-route.component';
import { ProductListComponent } from './product-list/product-list.component';
import { ProductService } from './product-list/product.service';
import { Product } from './product-list/product';
import { FormsModule } from '@angular/forms';
import { OrderByPipe } from './product-list/orderby.pipe';
import { ProductsModule } from './product-list/products.module';
import { CurrencyPipe } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { LoginComponent } from '../../../app2/src/app/login/login.component';
import { WelcomeComponent } from '../../../app1/src/app/welcome/welcome.component'

@NgModule({
  declarations: [
    AppComponent,
    EmptyRouteComponent,
    ProductListComponent,
    OrderByPipe, WelcomeComponent, LoginComponent
  ],
  imports: [
    BrowserModule, RouterModule,HttpClientModule, 
    AppRoutingModule, FormsModule, ReactiveFormsModule, CurrencyPipe
  ],
  providers: [ProductService, Pipe, OrderByPipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
    