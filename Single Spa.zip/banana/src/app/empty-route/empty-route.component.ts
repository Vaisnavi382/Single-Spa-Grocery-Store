import { Component } from '@angular/core';

@Component({
  selector: 'banana-empty-route',
  template: '',
})
export class EmptyRouteComponent {
}
