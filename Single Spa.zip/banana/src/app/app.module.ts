import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmptyRouteComponent } from './empty-route/empty-route.component';
import { HttpClientModule} from '@angular/common/http';
import { LoginComponent } from '../../../app2/src/app/login/login.component';
import { WelcomeComponent } from '../../../app1/src/app/welcome/welcome.component';
// import { bananaComponent } from './banana/banana.component';
import { ProductService } from '../../../product-list/src/app/product-list/product.service';
import { ProductListComponent } from '../../../product-list/src/app/product-list/product-list.component';
import { FormsModule } from '@angular/forms';
import { bananaComponent } from './banana/banana.component';
@NgModule({
  declarations: [
    AppComponent,
    EmptyRouteComponent,
    LoginComponent,
    WelcomeComponent,bananaComponent, ProductListComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule, HttpClientModule
  ],
  providers: [ProductService],
  bootstrap: [AppComponent]
})
export class AppModule { }
    