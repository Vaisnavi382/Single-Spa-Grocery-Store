import { Component,Input } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app2',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  constructor(private router: Router) {}
  username: string;
  password: string;


  onSubmit(): void {
    // if (this.username === 'admin' && this.password === 'admin') {
    //     this.router.navigate(['/product-list']); // Replace '/dashboard' with the desired route
    //   } else {
    //     // Handle login failure, display error message, etc.
    //     this.router.navigate(['/app1']);
    //   }
  }
}
