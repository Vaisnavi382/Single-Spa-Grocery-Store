const singleSpaAngularWebpack = require('single-spa-angular/lib/webpack').default;

module.exports = (angularWebpackConfig, options) => {
  const singleSpaWebpackConfig = singleSpaAngularWebpack(angularWebpackConfig, options);

  // Modify the output.publicPath option
  singleSpaWebpackConfig.output.publicPath = 'http://localhost:4206/';

  // Return the modified webpack configuration
  return singleSpaWebpackConfig;
};
