import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BottlegourdComponent } from './bottlegourd.component';

describe('BottlegourdComponent', () => {
  let component: BottlegourdComponent;
  let fixture: ComponentFixture<BottlegourdComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BottlegourdComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BottlegourdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
