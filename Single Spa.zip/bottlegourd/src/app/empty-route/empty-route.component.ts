import { Component } from '@angular/core';

@Component({
  selector: 'bottlegourd-empty-route',
  template: '',
})
export class EmptyRouteComponent {
}
