Steps to run :

1. npm i
2. ng serve

Running the root-html-file is important to run before running this application